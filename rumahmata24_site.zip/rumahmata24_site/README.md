# RumahMata24

Situs portal berita RumahMata24 (versi statis).

Cara hosting:
- GitHub Pages
- Netlify
- Vercel

Silakan edit konten sesuai kebutuhan.
