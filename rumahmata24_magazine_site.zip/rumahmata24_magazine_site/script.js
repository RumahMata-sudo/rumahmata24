
document.addEventListener('DOMContentLoaded', function(){
  // subscribe demo
  var form = document.getElementById('subscribe-form');
  if(form){
    form.addEventListener('submit', function(e){
      e.preventDefault();
      var email = document.getElementById('email').value;
      if(!email) return;
      var list = JSON.parse(localStorage.getItem('rm_sub')||'[]');
      list.push({email: email, date: new Date().toISOString()});
      localStorage.setItem('rm_sub', JSON.stringify(list));
      document.getElementById('sub-msg').textContent = 'Terima kasih — email Anda disimpan (demo).';
      form.reset();
    });
  }
});
