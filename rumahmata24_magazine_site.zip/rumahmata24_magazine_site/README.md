
RumahMata24 — Paket situs majalah (statis)

Cara publish cepat ke GitHub Pages:
1. Ekstrak ZIP dan buka folder 'rumahmata24_magazine_site'
2. Pastikan file berada di root (index.html, styles.css, script.js, images/)
3. Upload semua file ke repo GitHub Anda (rumahmata24)
   - Repository -> Add file -> Upload files -> drag semua file / folder
   - Commit changes
4. Settings -> Pages -> Source: Deploy from a branch -> Branch: main -> folder: /
5. Simpan. Situs akan tersedia di:
   https://RumahMata-sudo.github.io/rumahmata24

Atau deploy cepat ke Netlify (drag & drop folder).

